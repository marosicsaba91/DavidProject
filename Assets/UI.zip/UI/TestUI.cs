using UnityEngine;
using UnityEngine.UIElements;

public class TestUI : MonoBehaviour
{
    [SerializeField] UIDocument uiDocument;
    [SerializeField] VisualTreeAsset rowPrototype;

    [SerializeField] RowData[] rows;

    void Start()
    {
        VisualElement container =
            uiDocument.rootVisualElement.Q<VisualElement>("Column");

        container.Clear();

        foreach (RowData rowData in rows)
        {
            VisualElement rowVE = rowPrototype.Instantiate();
            Setup(rowData, rowVE);
            container.Add(rowVE);
        }
    }

    void Setup(RowData rowData, VisualElement rowVE)
    {
        rowVE.Q<Label>("Title").text = rowData.title;
        rowVE.Q<Label>("Description").text = rowData.description;
        Button b = rowVE.Q<Button>("Button");
        b.style.backgroundColor = rowData.color;

        b.clicked += () => OpenInfo(rowData);
    }

    void OpenInfo(RowData rowData)
    {
        Debug.Log($"OPEN: {rowData.title}   {rowData.description}");
    }
}
